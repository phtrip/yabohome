{
    "data": {
        "app_network": null,
        "appurl": {
            "agent_app_domain": "https://www.izhuangyang.com",
            "agent_pc_domain": "https://agent.ybagent10.com",
            "app_domain": "https://www.yb443.app",
            "customer_download": "",
            "h5_domain": "https://www.yabo392.com",
            "site_domain": "https://www.yabovip2019.com",
            "sport_domain": "https://www.yb73.app"
        },
        "banner": [
            {
                "link_url": "/app/fullMemberActivity",
                "title_img": "https://static.0am08m.com//prod/banner/m_48024315fa6b2ac2f94525eac41bd8c307cf203b.jpg"
            },
            {
                "link_url": "/app/joyous",
                "title_img": "https://static.0am08m.com//prod/banner/m_9fbcfcb754b5c0c2a97908a99c0e4bb8c8a5cc20.jpg"
            },
            {
                "link_url": "/app/client/1",
                "title_img": "https://static.0am08m.com//prod/banner/m_bf0934b2b68823dbf4948ccb3f94bd99fdf3211f.jpg"
            },
            {
                "link_url": "/app/gift",
                "title_img": "https://static.0am08m.com//prod/banner/m_6d33ba228c841ec70226c05722d9c73ff2f8f8b2.jpg"
            },
            {
                "link_url": "/agent/agent.html",
                "title_img": "https://static.0am08m.com//prod/banner/m_e6a551f60e0facc9329069eb8cc581b53ec5f25e.jpg"
            }
        ],
        "domain_status": {
            "code": 0,
            "message": "域名异常"
        },
        "h5_domain_arr": [
            "https://www.yabo317.com",
            "https://www.yabo805.com",
            "https://www.yabo809.com",
            "https://www.yabo810.com",
            "https://www.yabo324.com"
        ],
        "league_matches_info": null,
        "live_base_url": "https://videos.1ky5dz.com",
        "location": {
            "in_banlist": false,
            "information": "您所在的地区已被禁止访问我们的网站。给您造成的不便，敬请谅解。如有任何疑问，请通过在线客服，联系全年无休的在线客服支持团队，或发送邮件至cs@yabotiyu.net我们将竭诚为您服务。",
            "ip": "112.211.34.141",
            "location": {
                "city": "",
                "country": "菲律宾",
                "province": "菲律宾"
            },
            "result": "forbidden"
        },
        "maintain_info": [
            {
                "api_name": "AVIA",
                "api_title": "泛亚电竞",
                "id": "75",
                "maintain_desc": "尊敬的客户，泛亚电竞正在维护，给您造成不便，敬请谅解。"
            }
        ],
        "register_validate_type": "0",
        "report_api_list": [
            "report.ul68qh.com",
            "report.c593xw.com",
            "report.qyi5xx.com"
        ],
        "system_notify": [
            {
                "content": "尊敬的客户：我司泛亚电竞场馆于2020年05月06日（周三）14:00-05月07日（周四）12:05进行系统维护，届时泛亚电竞场馆将无法进行游戏和转账，其他场馆正常运行，请维护前将场馆内的余额转出，给您带来不便还请谅解。谢谢！",
                "created_at": "2020-05-06 13:06:14",
                "sort": "1",
                "title": "泛亚电竞维护",
                "updated_at": "2020-05-06 13:14:42",
                "url": ""
            },
            {
                "content": "尊敬的客户：泛亚电竞大改版，新增串关、快速投注功能，电脑端支持多种语言，还可自由切换不同模式，娱乐新体验！",
                "created_at": "2020-05-05 06:04:22",
                "sort": "1",
                "title": "泛亚电竞大改版",
                "updated_at": "2020-05-05 08:30:06",
                "url": ""
            },
            {
                "content": "尊敬的客户：电竞黄金周即将开启，5月2日-5月11日，电竞好礼领不停。好礼一：投注抽奖领更多；好礼二：负盈利天天返无顾虑；好礼三：聚焦lpl冠军赛事最高十六万奖金池为您加冕！电竞好礼，等您来领！",
                "created_at": "2020-05-01 18:43:11",
                "sort": "1",
                "title": "电竞黄金周 好礼领不停",
                "updated_at": "2020-05-03 11:04:10",
                "url": ""
            },
            {
                "content": "尊敬的客户：在2020年04月27日至05月31日期间，回归免费领最高888元，存款马上领高达1088元返利，召回老友即送千元现金。史上最强福利，不容错过！",
                "created_at": "2020-04-27 03:15:17",
                "sort": "1",
                "title": "王者归来 尊享888元",
                "updated_at": "2020-05-01 18:24:57",
                "url": ""
            },
            {
                "content": "尊敬的客户：\n活动一：5月1日-5月3日，每日投注真人场馆有效投注额≥500元，即抽8~888元劳动礼金，名额仅限888名。\n活动二：5月1日-5月10日真人排行争霸赛，赢取高达188,888元！详情请点击活动页查看！",
                "created_at": "2020-04-30 22:27:45",
                "sort": "1",
                "title": "劳动礼包 真人争霸",
                "updated_at": "2020-05-01 18:24:41",
                "url": ""
            },
            {
                "content": "尊敬的客户：五一去哪儿玩，亚博体育告诉您，5月1日-5月9日，史上最大优惠上线，5月1日当天存款立即挑战20%返利，完成每日流水要求必获得最高3088元满签奖金！钜惠即出，心为所动！",
                "created_at": "2020-04-30 23:10:29",
                "sort": "1",
                "title": "史无前例 挑战20%返利",
                "updated_at": "2020-05-01 18:20:26",
                "url": ""
            },
            {
                "content": "尊敬的客户：亚博web端升级已完成，全新界面，心动体验，更多惊喜等您一一探索！",
                "created_at": "2020-04-25 02:56:51",
                "sort": "1",
                "title": "亚博web端全新升级 邀您体验",
                "updated_at": "2020-04-28 03:02:14",
                "url": ""
            },
            {
                "content": "亚博APP由业界顶端技术团队研发制作，支持安卓、iOS下载版本，速度流畅、操作简便让您享受无限掌上乐趣！",
                "created_at": "2019-11-28 11:32:44",
                "sort": "3",
                "title": "亚博APP",
                "updated_at": "2020-04-11 02:25:36",
                "url": ""
            },
            {
                "content": "尊敬的客户：为了玩家的资金安全，防止资料外泄，请勿将个人账户密码提供给以亚博体育名义自称的工作人员，谨防上当受骗。如有任何问题，请您随时联系在线客服~！",
                "created_at": "2019-11-28 11:33:45",
                "sort": "2",
                "title": "温馨提示",
                "updated_at": "2020-04-11 02:23:58",
                "url": ""
            },
            {
                "content": "尊敬的客户：亚博彩票、棋牌震撼来袭 全新上线，丰富彩种任君挑选，感受棋牌不一样的3D视觉盛宴！",
                "created_at": "2020-03-14 00:14:13",
                "sort": "1",
                "title": "彩票棋牌齐上阵 亚博娱乐领航者",
                "updated_at": "2020-03-14 00:14:13",
                "url": ""
            },
            {
                "content": "亚博全员福利来袭！邀请好友前来游戏，好友首存即送您推荐礼金，首存越多奖励越高，详情请查看优惠页面。",
                "created_at": "2019-11-28 11:34:56",
                "sort": "1",
                "title": "亚博全员福利公告",
                "updated_at": "2020-02-27 18:29:55",
                "url": ""
            },
            {
                "content": "尊敬的客户：亚博给力优惠，每天签到，即可领取相应彩金，连续签到满7天，额外获得礼金188元。详情请查阅优惠活动页面。",
                "created_at": "2020-02-19 00:24:57",
                "sort": "1",
                "title": "亚博上上签 天天享礼金",
                "updated_at": "2020-02-19 00:29:17",
                "url": ""
            },
            {
                "content": "尊敬的客户：体育投注界面直播动画仅供参考，下注时请以当前盘口实时比分为准。感谢您的理解与支持！",
                "created_at": "2019-11-28 11:30:58",
                "sort": "1",
                "title": "关于体育直播动画",
                "updated_at": "2020-02-04 08:38:33",
                "url": ""
            },
            {
                "content": "尊敬的客户：为保证您的资金安全，我司暂不支持信用卡充值，为了更好的充值体验，建议您优先使用【网银转账】、【银联扫码】。如有任何问题，请您随时联系在线客服！给您带来的不便敬请谅解。",
                "created_at": "2019-11-28 11:34:20",
                "sort": "1",
                "title": "存款通知",
                "updated_at": "2019-11-30 22:12:22",
                "url": ""
            },
            {
                "content": "尊敬的客户：为了更好的让您畅玩无阻，亚博体育特为您打造了一条备用域名，当您无法用其他端口登录时，您可以使用备用域名进行登录游戏，详情请查看站内信通知！谢谢！",
                "created_at": "2019-11-28 11:38:07",
                "sort": "1",
                "title": "亚博官网备用域名通告",
                "updated_at": "2019-11-28 11:38:07",
                "url": ""
            },
            {
                "content": "尊敬的客户：亚博【新手任务】活动已开启，活动开始后新用户注册即送刮刮卡，完成存取款即送礼金，更有复活礼金和签到礼包等惊喜！复活金最高可领取1888元！详情请查看优惠活动！",
                "created_at": "2019-11-28 11:36:37",
                "sort": "1",
                "title": "玩转新手任务 惊喜马上领取",
                "updated_at": "2019-11-28 11:36:37",
                "url": ""
            }
        ],
        "version": null,
        "web_urls": [
            {
                "intro": "双赢下载页",
                "name": "sy_appdown",
                "url": "https://www.shuangyapp2.com"
            },
            {
                "intro": "全站下载页二维码链接",
                "name": "app_domain_qrcode",
                "url": "https://w.url.cn/s/AnZa2zs"
            },
            {
                "intro": "体育下载页二维码链接",
                "name": "sport_domain_qrcode",
                "url": "https://w.url.cn/s/AdDIEZV"
            },
            {
                "intro": "亚博棋牌app链接",
                "name": "ybqp_appdown",
                "url": "https://www.ybqpapp1.com"
            },
            {
                "intro": "主线客服",
                "name": "customer_service_main",
                "url": "https://chat.au819i.com/chat/chatClient/chatbox.jsp?companyID=80002385&configID=491"
            },
            {
                "intro": "次线客服",
                "name": "customer_service_2",
                "url": "https://chat.au819i.com/chat/chatClient/chatbox.jsp?companyID=80002385&configID=491"
            }
        ],
        "yabo_maintain": null
    },
    "flags": "1",
    "message": "查询成功",
    "status": "success",
    "status_code": 200
}