
// ====顶部时间=======================================================
function showLocale(objD){
	var str;
	var yy = objD.getYear();
	if(yy<1900) yy = yy+1900;
	var MM = objD.getMonth()+1;
	if(MM<10) MM = '0' + MM;
	var dd = objD.getDate();
	if(dd<10) dd = '0' + dd;
	var hh = objD.getHours();
	if(hh<10) hh = '0' + hh;
	var mm = objD.getMinutes();
	if(mm<10) mm = '0' + mm;
	var ss = objD.getSeconds();
	if(ss<10) ss = '0' + ss;
	str = yy + "-" + MM + "-" + dd + " " + hh + ":" + mm + ":" + ss + "  ";
	return(str);
}
function tick(){
	var today;
	today = new Date();
	document.getElementById("localtime").innerHTML = showLocale(today);
	window.setTimeout("tick()", 1000);
}
tick();
// ========================END===============================


// =============banner hover================================
(function() {
  // Init
  var container = document.getElementById("container"),
      inner = document.getElementById("inner");

  // Mouse
  var mouse = {
    _x: 0,
    _y: 0,
    x: 0,
    y: 0,
    updatePosition: function(event) {
      var e = event || window.event;
      this.x = e.clientX - this._x;
      this.y = (e.clientY - this._y) * -1;
    },
    setOrigin: function(e) {
      this._x = e.offsetLeft + Math.floor(e.offsetWidth / 2);
      this._y = e.offsetTop + Math.floor(e.offsetHeight / 2);
    },
    show: function() {
      return "(" + this.x + ", " + this.y + ")";
    }
  };

  mouse.setOrigin(container);

  var counter = 0;
  var refreshRate = 10;
  var isTimeToUpdate = function() {
    return counter++ % refreshRate === 0;
  };

  var onMouseEnterHandler = function(event) {
    update(event);
  };

  var onMouseLeaveHandler = function() {
    inner.style = "";
  };

  var onMouseMoveHandler = function(event) {
    if (isTimeToUpdate()) {
      update(event);
    }
  };

  var update = function(event) {
    mouse.updatePosition(event);
    updateTransformStyle(
      (mouse.y / inner.offsetHeight / 2).toFixed(2),
      (mouse.x / inner.offsetWidth / 2).toFixed(2)
    );
  };

  var updateTransformStyle = function(x, y) {
    var style = "rotateX(" + x + "deg) rotateY(" + y + "deg)";
    inner.style.transform = style;
    inner.style.webkitTransform = style;
    inner.style.mozTranform = style;
    inner.style.msTransform = style;
    inner.style.oTransform = style;
  };

  container.onmousemove = onMouseMoveHandler;
  container.onmouseleave = onMouseLeaveHandler;
  container.onmouseenter = onMouseEnterHandler;
})();
// ========================END===============================

// =============banner 轮播================================
$(function() {
    init();
    changImg(); //解决第一次第一张到第二张的时间间隔
    start();

    $(".btnnum li").hover(function(){
        clearInterval(timer);
    },function(){
    	console.log(index)
        start();
    })
    $(".btnnum li").on("click", function(){
        index=$(this).index();
        changImg(index)
    });
});
var index = 0;
var timer; //定时器
//定时器 播放
//初始化
function init() {
    var len = $('.banList li').length; //获取图片有多少张
    var html = '';
    $('.btnnum li').eq(0).addClass('current active');
}
// ========================END===============================

//图片轮播
function changImg(num) {
    if (num == 'auto') { //定时器自动调用
        num = index;
    } else { //鼠标放上的时候 清楚定时器
        clearInterval(timer);
    }
    $('.banList li').eq(num).addClass('bannershow banneropacity').siblings().removeClass('bannershow banneropacity');
    $('.btnnum li').eq(num).addClass("current active").siblings().removeClass("current active");
    $(".banList li").eq(num-1).addClass('finished');
    index++;
    if (index == $('#img img').length) { //最后一张
        index = 0; //第一张
    }
}
function start() {
    timer = setInterval('changImg("auto")', 2500);
}
//鼠标离开之后 又要自动播放
function reStart(num) {
    index = num;
    changImg(num);
    start();
}

// ========================END===============================

// ==========circle process==================================
(function() {
	var canvas = document.getElementById('canvas'),
	circlesCreated = false;
	function onScroll() {
		if (!circlesCreated && elementInViewport(canvas)) {
			circlesCreated = true;
			createCircles();
		} else if (elementInViewport(canvas)) {
			circlesCreated = true;
		} else {
			circlesCreated = false;
		}
	}
	function elementInViewport(el) {
	    var rect = el.getBoundingClientRect();

	    return (
	      rect.top  >= 0 &&
	      rect.left >= 0 &&
	      rect.top  <= (window.innerHeight || document.documentElement.clientHeight)
	    );
	}
	function createCircles() {
		var colors = [
				['#524e6a', '#eaba9e'], ['#524e6a', '#eaba9e'], ['#524e6a', '#eaba9e'], ['#524e6a', '#eaba9e']
			],
			circles = [];
		for (var i = 1; i <= colors.length; i++) {
			var child = document.getElementById('circles-' + i);
				if (i === 1 || i === 1) {
					percentage = 60
				} else if (i === 3) {
					percentage = 90				
				} else if (i === 4) {
					percentage = 22
				}

				circle = Circles.create({
					id:         child.id,
					value:      percentage,
					radius:     40,
					width:      6,
					colors:     colors[i - 1],
				 	duration:   1500,
					textClass: 'circles-text',
					text: function(value) {
						if (value === 22) {
							return value + '<span>家</span>';
						} else {
							return value + '<span>秒</span>';
						}
					}
			});
			circles.push(circle);
		}
	}
	if (!circlesCreated && elementInViewport(canvas)) {
		circlesCreated = true;
		createCircles();
	}
  	window.onscroll = onScroll;
  	window.onmousewheel = function (e) {
        onScroll()
    }
})();
// ========================END===============================

$(function() {
    $('.btn-group button').on("click", function() { // tab切换
        var cur=$(this).index();
        $(this).addClass('active').siblings().removeClass('active');
        $(this).parent().next('.bg-common').find('.list').eq(cur).addClass('selected').siblings().removeClass('selected');
    });
})